/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praticando_java;

/**
 *
 * @author lsnunes
 */
import java.util.Scanner;

public class Praticando_java {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int resultado;
        int n1;
        int n2;
        
        System.out.println("Digite um numero inteiro: ");
        n1 = scanner.nextInt();
        
        System.out.println("Digite outro numero inteiro: ");
        n2 = scanner.nextInt();
        
        resultado = (n1 + n2);
        
        System.out.println("A soma de "+ n1+ " com "+n2+" = " + resultado);
    }
}

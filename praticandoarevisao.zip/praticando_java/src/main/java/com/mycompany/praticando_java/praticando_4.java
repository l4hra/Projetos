/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praticando_java;

/**
 *
 * @author lsnunes
 */
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

public class praticando_4 {
    public static void main(String[] args) throws IOException {

        String nomeArquivo = JOptionPane.showInputDialog("Informe um nome para o arquivo:");
        String localSalvo = JOptionPane.showInputDialog("Informe o local para salvar seu arquivo:");
     
        String nome = JOptionPane.showInputDialog("Digite o nome do lutador: ");

        String input1 = JOptionPane.showInputDialog("Digite o peso do lutador (em kg): ");
        double peso = Double.parseDouble(input1);

      
        
       

        String categoria;
        if (peso < 65) {
            categoria = "Pena";
        } else if (peso >= 65 && peso < 72) {
            categoria = "Leve";
        } else if (peso >= 72 && peso < 79) {
            categoria = "Ligeiro";
        } else {
            categoria = "Categoria não definida";
        }
       FileWriter arquivo = new FileWriter(localSalvo+nomeArquivo+".txt");
        PrintWriter escrever = new PrintWriter(arquivo);
        
      System.out.println("Nome do lutador: " + nome);
        System.out.println("O peso do lutador: " + peso);
        escrever.printf("O lutador " + nome + " tem "+ peso + " kg e se enquada na categoria "+categoria);
        arquivo.close();
    }
}
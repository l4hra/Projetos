/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praticando_java;

import javax.swing.JOptionPane;

/**
 *
 * @author lsnunes
 */
public class praticando_2_1 {
    
    public static void main(String[] args) {
        int resultado;
        int n1;
        int n2;
        
       String input1 = JOptionPane.showInputDialog ("Digite um numero: ");
        n1 = Integer.parseInt(input1);
        
       String input2 = JOptionPane.showInputDialog("Digite outro numero: ");
        n2 = Integer.parseInt(input2);
        
       if ((n1 >= 0 && n2 >= 0) || (n1 < 0 && n2 < 0)) {
            resultado = n1 + n2;
           JOptionPane.showMessageDialog(null, "A soma de " + n1 + " com " + n2 + " = " + resultado);
        }else{
            JOptionPane.showMessageDialog(null,"Dados de Entrada são Inválidos");
        }
      
        
}
}

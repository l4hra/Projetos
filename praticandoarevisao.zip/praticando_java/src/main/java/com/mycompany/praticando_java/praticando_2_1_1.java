/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.praticando_java;

import javax.swing.JOptionPane;

/**
 *
 * @author lsnunes
 */
public class praticando_2_1_1 {
    
    public static void main(String[] args) {
        int n1;
        int n2;
        int n3;
        
       JOptionPane.showMessageDialog(null, "Cada numero corresponde a um dos lado dos triângulos, podendo ser: equilátero, isósceles ou escaleno. ");
       
       String input1 = JOptionPane.showInputDialog ("Digite um numero: ");
        n1 = Integer.parseInt(input1);
        
       String input2 = JOptionPane.showInputDialog("Digite outro numero: ");
        n2 = Integer.parseInt(input2);
        
       String input3 = JOptionPane.showInputDialog("Digite mais um numero: ");
       n3 = Integer.parseInt(input3);
        
       if (n1 == n2 && n2 == n3) {         
           JOptionPane.showMessageDialog(null, "É um triangulo equilatero ");
        }else if(n1 == n2 || n1 == n3 || n2 == n3){
            JOptionPane.showMessageDialog(null,"É um triangulo isosceles");
        }else{
            JOptionPane.showMessageDialog(null, "É um triangulo escaleno");
        }
      
        
}
}

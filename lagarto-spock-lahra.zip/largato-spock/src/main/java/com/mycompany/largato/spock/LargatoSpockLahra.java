/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.largato.spock;

import java.util.Scanner;

/**
 *
 * @author lsnunes
 */
public class LargatoSpockLahra {

    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        String continuar = "S";

        while(continuar.equals("S")) {
        System.out.println("BEM VINDO AO JOKENPO");
        System.out.println("----REGRAS ----");
        System.out.println("-------------------------------");
        System.out.println("Pedra vence a tesoura e perde pro papel");
        System.out.println("Tesoura vence o papel e perde para pedra");
        System.out.println("Papel vence a pedra e perde para tesoura");
        System.out.println("Spock vence a tesoura e perde para o lagarto");
        System.out.println("Lagarto vence o spock e perde para pedra");

        System.out.println("Jogador 1, digite sua escolha:");
        String es1 = scanner.nextLine().toUpperCase();

        System.out.println("Jogador 2, digite sua escolha:");
        String es2 = scanner.nextLine().toUpperCase();

        //verificação de vencedor
        verificaVencedor(es1, es2);
        
         System.out.println("Deseja continuar? (S/N)");
            continuar = scanner.nextLine().toUpperCase();
        }
    }

    public static void verificaVencedor(String es1, String es2) {
        //empate
        if(es1.equals(es2)) {
            System.out.println("EMPATE ");
        } else {
            //jogador um escolheu pedra
            if (es1.equals("PEDRA")) {
                if (es2.equals("TESOURA") || es2.equals("LAGARTO")) {
                    System.out.println("JOGADOR UM VENCEU");
                } else {
                    System.out.println("JOGADOR DOIS VENCEU");
                }
            //jogador um escolheu tesoura
            } else if (es1.equals("TESOURA")) {
                if (es2.equals("PAPEL") || es2.equals("LAGARTO")) {
                    System.out.println("JOGADOR UM VENCEU");
                } else {
                    System.out.println("JOGADOR DOIS VENCEU");
                }
            //jogador um escolheu papel
            } else if (es1.equals("PAPEL")) {
                if (es2.equals("PEDRA") || es2.equals("SPOCK")) {
                    System.out.println("JOGADOR UM VENCEU");
                } else {
                    System.out.println("JOGADOR DOIS VENCEU");
                }
            //jogador um escolheu spock
            } else if (es1.equals("SPOCK")) {
                if (es2.equals("TESOURA") || es2.equals("PEDRA")) {
                    System.out.println("JOGADOR UM VENCEU");
                } else {
                    System.out.println("JOGADOR DOIS VENCEU");
                }
            //jogador um escolheu lagarto
            } else if (es1.equals("LAGARTO")) {
                if (es2.equals("SPOCK") || es2.equals("PAPEL")) {
                    System.out.println("JOGADOR UM VENCEU");
                } else {
                    System.out.println("JOGADOR DOIS VENCEU");
                }
            }
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_tela_19_04;

/**
 *
 * @author lnunes
 */
public class Lahra_tela_19_04 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

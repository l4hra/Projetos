/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_27;

import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author lnunes
 */
public class Lahra_27 extends JFrame{
 private JTextField campoTexto1, campoTexto2,campoTexto3, campoTexto4, campoTexto5,campoTexto6,campoTexto7,campoTexto8,campoTexto9,campoTexto10,campoTexto11;
    private JButton botao1,botao2;
    
    
    public  Lahra_27(){
       setTitle("Tela de cadastro PCD");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000,500);
        setLocationRelativeTo(null);
        
        
        campoTexto1 = new JTextField(10);
        campoTexto2 = new JTextField(10);
        campoTexto3 = new JTextField(10);
        campoTexto4 = new JTextField(10);
        campoTexto5 = new JTextField(10);
        campoTexto6 = new JTextField(10);
        campoTexto7 = new JTextField(10);
        campoTexto8 = new JTextField(10);
        campoTexto9 = new JTextField(10);  
        campoTexto10 = new JTextField(10);
        campoTexto11 = new JTextField(10);
        
        botao1 = new JButton("Cadastrar");
        botao2 = new JButton("Cancelar");
        
             
        JRadioButton rbtn1 = new JRadioButton("Masc");
        rbtn1.setActionCommand("Masc");
        JRadioButton rbtn2 = new JRadioButton("Fem");
        rbtn2.setActionCommand("Fem");
        
        JRadioButton rbtn3 = new JRadioButton("Auditiva");
        JRadioButton rbtn4 = new JRadioButton("Visual");
        JRadioButton rbtn5 = new JRadioButton("Intelectual");
        JRadioButton rbtn6 = new JRadioButton("Psicossocial");
        JRadioButton rbtn7 = new JRadioButton("Multipla");
        
        JRadioButton rbtn8 = new JRadioButton("Sim");
        JRadioButton rbtn9 = new JRadioButton("Não");
        
        ButtonGroup bg = new ButtonGroup();  
        bg.add(rbtn1);
        bg.add(rbtn2); 
        
        setLayout(new GridLayout(20,3));
        
        add(new JLabel("Nome: "));
        add(campoTexto1);
        add(new JLabel("Sobrenome: "));
        add(campoTexto2);
        add(new JLabel("Cpf: "));
        add(campoTexto3);
        
        add(new JLabel("Idade: "));
        add(campoTexto4); 
        add(new JLabel("Estado: "));
        add(campoTexto5); 
        add(new JLabel("Cidade: "));
        add(campoTexto6); 
        add(new JLabel("Municipio: "));
        add(campoTexto7); 
        add(new JLabel("Bairro: "));
        add(campoTexto8); 
        add(new JLabel("Rua: "));
        add(campoTexto9);      
        add(new JLabel("Numero da casa: "));
        add(campoTexto10); 
        add(new JLabel("Contato: (E-mail ou telefone) "));
        add(campoTexto11); 
        
        add(new JLabel("Tipo da deficiencia: "));
        add(rbtn3);
        add(rbtn4);
        add(rbtn6);
        add(rbtn5);
        add(rbtn7);
         
        add(new JLabel("Recebe algum auxilio?"));
        add(rbtn8);
        add(rbtn9);
        
        add(new JLabel("Genero: "));
        add(rbtn1);
        add(rbtn2);
        
        add(botao1);
        add(botao2);
        
        
        setVisible(true);

}
    
    public static void main(String[] args) {
       SwingUtilities.invokeLater(new Runnable(){
         public void run(){
             new Lahra_27();
         }
     }) ;
    }
}

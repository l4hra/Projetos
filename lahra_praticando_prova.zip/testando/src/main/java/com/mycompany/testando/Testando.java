/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testando;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author lnunes
 */
public class Testando {

    public static void main(String[] args) throws IOException {
       String local = "D:\\Users\\lnunes\\Documents\\mikael\\";
       
       JOptionPane.showMessageDialog(null, "Ensaiando para a prova!");
       
       String input1 = JOptionPane.showInputDialog(null, "Digite sua idade");
       int idade = Integer.parseInt(input1);
       
       String nome = JOptionPane.showInputDialog(null, "Digite seu nome");
       
       FileWriter arquivo = new FileWriter( local + "vida.txt");
       PrintWriter escrever = new PrintWriter(arquivo);
       
       
       escrever.printf("Olá " + nome + " sua idade é: " + idade);
       arquivo.close();
    }
}

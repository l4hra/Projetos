/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tela_com_java_lahra;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.*;


/**
 *
 * @author lsnunes
 */
public class Tela_com_java_lahra extends JFrame{
  private JTextField campoTexto1, campoTexto2, campoTexto3, campoTexto4;
    private JButton botao1,botao2;
    
    
    
    
    public  Tela_com_java_lahra(){
        setTitle("Tela de cadastro");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,200);
        setLocationRelativeTo(null);
        
        
        campoTexto1 = new JTextField(10);
        campoTexto2 = new JTextField(10);
        campoTexto3 = new JTextField(10);
        campoTexto4 = new JTextField(30);
        
        
        botao1 = new JButton("Ok");
        botao2 = new JButton("Cancelar");
        
       
       
      
        
        JRadioButton rbtn1 = new JRadioButton("Masc");
        rbtn1.setActionCommand("Masc");
        JRadioButton rbtn2 = new JRadioButton("Fem");
        rbtn2.setActionCommand("Fem");
        ButtonGroup bg = new ButtonGroup();  
        bg.add(rbtn1);
        bg.add(rbtn2); 
        
        setLayout(new GridLayout(6,3));
        
        add(new JLabel("Nome: "));
        add(campoTexto1);
        add(new JLabel("Sobrenome: "));
        add(campoTexto2);
        add(new JLabel("Genero: "));
        add(rbtn1);
        add(rbtn2);
        add(new JLabel("Idade: "));
        add(campoTexto4);  
         add(new JLabel("Descrição: "));
        add(campoTexto4);  
        add(botao1);
        add(botao2);
        
        
        setVisible(true);

    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable(){
         public void run(){
             new Tela_com_java_lahra();
         }
     }) ;
     
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.testando;


import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.*;


/**
 *
 * @author lnunes
 */
public class Testando extends JFrame{

    private JTextField campoTexto1, campoTexto2, campoTexto3;
    private JButton botao1,botao2;
    
    
    
    
    public Testando(){
        setTitle("Telinha aiai");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,200);
        setLocationRelativeTo(null);
        
        
        campoTexto1 = new JTextField(10);
        campoTexto2 = new JTextField(10);
        campoTexto3 = new JTextField(10);
        
        
        botao1 = new JButton("Botao 1");
        botao2 = new JButton("Botao 2");
        
        setLayout(new GridLayout(4,2));
        
        add(new JLabel("Campo1: "));
        add(campoTexto1);
        add(new JLabel("Campo2: "));
        add(campoTexto2);
        add(new JLabel("Campo3: "));
        add(campoTexto3);
        add(botao1);
        add(botao2);
        
        setVisible(true);

    }
    public static void main(String[] args) {
      
     SwingUtilities.invokeLater(new Runnable(){
         public void run(){
             new Testando();
         }
     }) ;
     
 
    }
}

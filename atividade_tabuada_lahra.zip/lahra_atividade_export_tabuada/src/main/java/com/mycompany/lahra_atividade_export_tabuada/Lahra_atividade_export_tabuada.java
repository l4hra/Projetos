/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_atividade_export_tabuada;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author lnunes
 */
public class Lahra_atividade_export_tabuada {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        int valorUsuario = 0;
        String nomeArquivo = "";
        Date date = new Date();
        String localSalvo = "";
        
        
        System.out.println("----------TABUADA----------");
        System.out.println("\nInforme um nome para o arquivo: ");
        nomeArquivo = sc.next();
        sc.nextLine();
        
        System.out.print("\n Informe um valor para a tabuada: ");
        valorUsuario = sc.nextInt();
        sc.nextLine();
        
        System.out.print("\n Informe o local para salvar seu arquivo: ");
        localSalvo = sc.next();
        sc.nextLine();
        
        FileWriter arquivo = new FileWriter(localSalvo+nomeArquivo+".txt");
        PrintWriter escrever = new PrintWriter(arquivo);
        
        escrever.printf("Tabuada do " + valorUsuario + " | " + date + "\n");
        escrever.printf("---------------");
        for (int i = 1; i <= 10; i++){
        escrever.printf("\n" + i + "x" + valorUsuario + " = " + (i * valorUsuario));
        
        }
        escrever.printf("----------------");
        arquivo.close();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.teste01;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author lnunes
 */
public class Lahra_erros_vetor_notas {

    public static void main(String[] args) throws IOException {
       String s = "";
        float[] notas = new float[2];
        float media = 0;

        DataInputStream dado = new DataInputStream(System.in);

        for (int i = 0; i < notas.length; i++) {
            System.out.println("Entre com a nota " + (i + 1) + ": ");
            s = dado.readLine();
            notas[i] = Float.parseFloat(s);
        }

        media = (notas[0] + notas[1]) / 2;
        System.out.println("Sua media é: " + media);
    }
}


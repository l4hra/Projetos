/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lahra_atividade_export_tabuada;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author lnunes
 */
public class Lahra_atividade_export_tabuada {

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);     
        Date date = new Date();
      
        
        
        System.out.println("----------TABUADA----------");
        String nomeArquivo = JOptionPane.showInputDialog("Informe um nome para o arquivo:");
        int valorUsuario = Integer.parseInt(JOptionPane.showInputDialog("Informe um valor para a tabuada:"));
        String localSalvo = JOptionPane.showInputDialog("Informe o local para salvar seu arquivo:");
        
        FileWriter arquivo = new FileWriter(localSalvo+nomeArquivo+".txt");
        PrintWriter escrever = new PrintWriter(arquivo);
        
        escrever.printf("Tabuada do " + valorUsuario + " | " + date + "\n");
        escrever.printf("---------------");
        tabuada(valorUsuario, escrever);
        escrever.printf("----------------");
        arquivo.close();
        
    }
    public static void tabuada(int valorUsuario, PrintWriter escrever) {
        for (int i = 1; i <= 10; i++) {
            escrever.printf("\n" + i + "x" + valorUsuario + " = " + (i * valorUsuario));
        }
    }
}
